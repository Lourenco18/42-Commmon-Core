"""Test suite for call-me-maybe."""
